(function(){

  const DEFAULT_GESTURES = ["hello","thank you","yes","no","how much","please","stop","help"];
  let gestures = [...DEFAULT_GESTURES];
  let sampleCounts = {};
  gestures.forEach(g => sampleCounts[g] = 0);

  const video = document.getElementById('video');
  const overlay = document.getElementById('overlay');
  const ctx = overlay.getContext('2d');
  const startBtn = document.getElementById('startBtn');
  const stopBtn = document.getElementById('stopBtn');
  const speakBtn = document.getElementById('speakBtn');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const gestureValue = document.getElementById('gestureValue');
  const gestureConf = document.getElementById('gestureConf');
  const sentenceText = document.getElementById('sentenceText');
  const clearSentenceBtn = document.getElementById('clearSentenceBtn');
  const gestureSelect = document.getElementById('gestureSelect');
  const newGestureInput = document.getElementById('newGestureInput');
  const addGestureBtn = document.getElementById('addGestureBtn');
  const captureBtn = document.getElementById('captureBtn');
  const sampleCountEl = document.getElementById('sampleCount');
  const gestureChips = document.getElementById('gestureChips');
  const logEl = document.getElementById('log');

  const btnSignMode = document.getElementById('btnSignMode');
  const btnSpeechMode = document.getElementById('btnSpeechMode');
  const signPane = document.getElementById('signPane');
  const speechPane = document.getElementById('speechPane');
  const startListenBtn = document.getElementById('startListenBtn');
  const stopListenBtn = document.getElementById('stopListenBtn');
  const speechStatusDot = document.getElementById('speechStatusDot');
  const speechStatusText = document.getElementById('speechStatusText');
  const micIndicator = document.getElementById('micIndicator');
  const signCueGrid = document.getElementById('signCueGrid');

  function log(msg){
    const d = document.createElement('div');
    const t = new Date().toLocaleTimeString();
    d.textContent = `[${t}] ${msg}`;
    logEl.prepend(d);
  }

  function refreshGestureUI(){
    gestureSelect.innerHTML = '';
    gestureChips.innerHTML = '';
    gestures.forEach(g => {
      const opt = document.createElement('option');
      opt.value = g; opt.textContent = g;
      gestureSelect.appendChild(opt);

      const chip = document.createElement('div');
      chip.className = 'chip' + (sampleCounts[g] > 0 ? ' trained' : '');
      chip.textContent = `${g} (${sampleCounts[g]})`;
      gestureChips.appendChild(chip);
    });
    sampleCountEl.textContent = gestures.length + ' gestures available';
    renderSignCues();
  }

  function renderSignCues(){
    signCueGrid.innerHTML = '';
    gestures.slice(0,8).forEach(g => {
      const el = document.createElement('div');
      el.className = 'sign-cue';
      el.innerHTML = `<div class="word">${g}</div><div class="desc">tap to preview cue</div>`;
      el.style.cursor = 'pointer';
      el.addEventListener('click', () => showSignCue(g));
      signCueGrid.appendChild(el);
    });
  }

  addGestureBtn.addEventListener('click', () => {
    const val = newGestureInput.value.trim().toLowerCase();
    if(!val) return;
    if(!gestures.includes(val)){
      gestures.push(val);
      sampleCounts[val] = 0;
      refreshGestureUI();
      log(`Added new gesture: "${val}"`);
    }
    newGestureInput.value = '';
  });

  clearSentenceBtn.addEventListener('click', () => {
    sentenceText.textContent = 'Translated phrase appears here';
  });

  // ---------- Mode switching ----------
  btnSignMode.addEventListener('click', () => setMode('sign'));
  btnSpeechMode.addEventListener('click', () => setMode('speech'));

  function setMode(mode){
    if(mode === 'sign'){
      btnSignMode.classList.add('active');
      btnSpeechMode.classList.remove('active');
      signPane.style.display = 'block';
      speechPane.style.display = 'none';
    } else {
      btnSpeechMode.classList.add('active');
      btnSignMode.classList.remove('active');
      speechPane.style.display = 'block';
      signPane.style.display = 'none';
    }
  }

  // ---------- MediaPipe Hands setup ----------
  let hands, camera, running = false;
  let knn = knnClassifier.create();
  let lastLandmarks = null;
  let lastPrediction = null;

  function setStatus(state, text){
    statusDot.className = 'status-dot' + (state ? ' ' + state : '');
    statusText.textContent = text;
  }

  function normalizeLandmarks(landmarks){
    // landmarks: array of {x,y,z} in [0,1] image coords
    const wrist = landmarks[0];
    let coords = landmarks.map(p => [p.x - wrist.x, p.y - wrist.y, p.z - wrist.z]);
    // scale-normalize by max distance from wrist so it's roughly translation/scale invariant
    let maxDist = 0;
    coords.forEach(c => {
      const d = Math.sqrt(c[0]*c[0] + c[1]*c[1] + c[2]*c[2]);
      if(d > maxDist) maxDist = d;
    });
    if(maxDist === 0) maxDist = 1;
    coords = coords.map(c => [c[0]/maxDist, c[1]/maxDist, c[2]/maxDist]);
    return coords.flat();
  }

  function drawLandmarks(landmarks){
    ctx.clearRect(0,0,overlay.width, overlay.height);
    const w = overlay.width, h = overlay.height;
    ctx.fillStyle = '#3fae7d';
    ctx.strokeStyle = 'rgba(63,174,125,0.6)';
    ctx.lineWidth = 2;
    const HAND_CONNECTIONS = [
      [0,1],[1,2],[2,3],[3,4],
      [0,5],[5,6],[6,7],[7,8],
      [0,9],[9,10],[10,11],[11,12],
      [0,13],[13,14],[14,15],[15,16],
      [0,17],[17,18],[18,19],[19,20],
      [5,9],[9,13],[13,17]
    ];
    HAND_CONNECTIONS.forEach(([a,b]) => {
      ctx.beginPath();
      ctx.moveTo(landmarks[a].x * w, landmarks[a].y * h);
      ctx.lineTo(landmarks[b].x * w, landmarks[b].y * h);
      ctx.stroke();
    });
    landmarks.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, 3, 0, Math.PI*2);
      ctx.fill();
    });
  }

  async function onResults(results){
    if(results.multiHandLandmarks && results.multiHandLandmarks.length > 0){
      const landmarks = results.multiHandLandmarks[0];
      lastLandmarks = landmarks;
      drawLandmarks(landmarks);
      captureBtn.disabled = false;

      if(knn.getNumClasses() > 0){
        const features = normalizeLandmarks(landmarks);
        const tensor = tf.tensor1d(features);
        const res = await knn.predictClass(tensor, 5);
        tensor.dispose();
        lastPrediction = res;
        const confidence = (res.confidences[res.label] * 100).toFixed(0);
        if(res.confidences[res.label] > 0.55){
          gestureValue.textContent = res.label;
          gestureConf.textContent = confidence + '% confidence';
          speakBtn.disabled = false;
        } else {
          gestureValue.textContent = 'uncertain';
          gestureConf.textContent = confidence + '% confidence — hold steadier or add more samples';
        }
      } else {
        gestureValue.textContent = 'no gestures trained yet';
        gestureConf.textContent = 'capture a few samples for each sign on the right';
      }
    } else {
      ctx.clearRect(0,0,overlay.width, overlay.height);
      lastLandmarks = null;
      captureBtn.disabled = true;
    }
  }

  startBtn.addEventListener('click', async () => {
    setStatus('', 'Requesting camera access…');
    try{
      hands = new Hands({locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.4.1675469240/${file}`});
      hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.6,
        minTrackingConfidence: 0.6
      });
      hands.onResults(onResults);

      camera = new Camera(video, {
        onFrame: async () => { await hands.send({image: video}); },
        width: 640,
        height: 480
      });
      await camera.start();

      video.addEventListener('loadedmetadata', () => {
        overlay.width = video.videoWidth;
        overlay.height = video.videoHeight;
      });

      running = true;
      startBtn.disabled = true;
      stopBtn.disabled = false;
      setStatus('ok', 'Camera running — hand tracking active');
      log('Camera started, hand tracking initialized');
    } catch(err){
      setStatus('err', 'Camera access failed: ' + err.message);
      log('Error starting camera: ' + err.message);
    }
  });

  stopBtn.addEventListener('click', () => {
    if(camera){ camera.stop(); }
    const stream = video.srcObject;
    if(stream){ stream.getTracks().forEach(t => t.stop()); }
    ctx.clearRect(0,0,overlay.width, overlay.height);
    running = false;
    startBtn.disabled = false;
    stopBtn.disabled = true;
    captureBtn.disabled = true;
    setStatus('', 'Camera stopped');
    log('Camera stopped');
  });

  captureBtn.addEventListener('click', () => {
    if(!lastLandmarks) return;
    const label = gestureSelect.value;
    const features = normalizeLandmarks(lastLandmarks);
    const tensor = tf.tensor1d(features);
    knn.addExample(tensor, label);
    tensor.dispose();
    sampleCounts[label] = (sampleCounts[label] || 0) + 1;
    refreshGestureUI();
    log(`Captured sample for "${label}" (${sampleCounts[label]} total)`);
  });

  speakBtn.addEventListener('click', () => {
    if(!lastPrediction) return;
    const phrase = lastPrediction.label;
    sentenceText.textContent = '"' + phrase + '"';
    const utter = new SpeechSynthesisUtterance(phrase);
    utter.rate = 0.95;
    speechSynthesis.speak(utter);
    log(`Spoke: "${phrase}"`);
  });

  // ---------- Speech to sign ----------
  let recognition = null;
  let listening = false;

  function showSignCue(word){
    speechStatusText.textContent = `showing cue for "${word}"`;
    log(`Sign cue displayed for "${word}"`);
  }

  function setupRecognition(){
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if(!SR){
      speechStatusText.textContent = 'Speech recognition not supported in this browser — try Chrome';
      startListenBtn.disabled = true;
      return null;
    }
    const r = new SR();
    r.continuous = true;
    r.interimResults = false;
    r.lang = 'en-IN';
    r.onresult = (e) => {
      const transcript = e.results[e.results.length - 1][0].transcript.trim().toLowerCase();
      speechStatusText.textContent = `heard: "${transcript}"`;
      log(`Heard: "${transcript}"`);
      const match = gestures.find(g => transcript.includes(g));
      if(match){
        showSignCue(match);
      } else {
        showSignCue(transcript.split(' ')[0] || transcript);
      }
    };
    r.onerror = (e) => {
      speechStatusDot.className = 'status-dot err';
      speechStatusText.textContent = 'Recognition error: ' + e.error;
    };
    r.onend = () => {
      if(listening) r.start(); // keep listening continuously
    };
    return r;
  }

  startListenBtn.addEventListener('click', () => {
    if(!recognition) recognition = setupRecognition();
    if(!recognition) return;
    listening = true;
    recognition.start();
    startListenBtn.disabled = true;
    stopListenBtn.disabled = false;
    micIndicator.style.borderColor = '#3fae7d';
    speechStatusDot.className = 'status-dot ok';
    speechStatusText.textContent = 'Listening…';
    log('Speech recognition started');
  });

  stopListenBtn.addEventListener('click', () => {
    listening = false;
    if(recognition) recognition.stop();
    startListenBtn.disabled = false;
    stopListenBtn.disabled = true;
    speechStatusDot.className = 'status-dot';
    speechStatusText.textContent = 'Speech recognition idle';
    log('Speech recognition stopped');
  });

  refreshGestureUI();
  log('App loaded. Click "Start camera" to begin, or add/select gestures to train.');

})();
