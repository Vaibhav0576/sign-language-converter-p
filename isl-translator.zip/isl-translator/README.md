# ISL Translate — Real-Time Sign Language Translator

A working hackathon prototype: translates hand gestures to speech, and speech to sign cues, entirely in the browser. No backend, no build step, no training data to collect in advance.

## How it works

1. **Hand tracking** — [MediaPipe Hands](https://developers.google.com/mediapipe) reads the webcam feed and returns 21 3D landmark points per hand, live, in the browser.
2. **Gesture classification** — landmarks are normalized (relative to the wrist, scale-invariant) and fed into a [TensorFlow.js KNN classifier](https://github.com/tensorflow/tfjs-models/tree/master/knn-classifier). You train it live during the demo: hold a sign, click "capture sample," repeat 15-30 times per gesture, and it starts recognizing that sign in real time.
3. **Sign → speech** — once a gesture is classified with reasonable confidence, click "speak translation" to have the browser read it aloud via the Web Speech API (`SpeechSynthesisUtterance`).
4. **Speech → sign** — switch modes to use the microphone. Speech is transcribed live via the Web Speech API (`SpeechRecognition`) and matched against your trained vocabulary, showing a text cue card for that word. (Swap in real sign photos/video clips here for a stronger demo — see "Next steps" below.)

## Running it

No install needed for the demo itself — it's static HTML/JS pulling libraries from a CDN.

```bash
cd isl-translator
python3 -m http.server 8000
```

Then open `http://localhost:8000` in **Chrome** (best Web Speech API + camera support). Camera and microphone access require either `localhost` or HTTPS — it will not work opened directly as a `file://` URL in most browsers.

If you want to deploy it for judges to try on their own phones, any static host works (GitHub Pages, Netlify, Vercel) — HTTPS is provided automatically by all three.

## Using it in your demo

1. Click **Start camera**, allow camera access.
2. Pick a gesture from the dropdown (or add your own via the text box — e.g. "how much", "thank you").
3. Hold the sign steady in frame and click **Capture sample** 15-30 times. Vary the hand position slightly between captures (distance from camera, slight rotation) so the classifier generalizes.
4. Repeat for each gesture in your vocabulary — start with 4-6 for a tight demo.
5. Once trained, hold a sign in frame — the right panel shows the live prediction and confidence. Click **Speak translation** to hear it.
6. Switch to **Speech → sign** mode, click **Start listening**, and speak one of your trained words — a cue card appears.

Do the training live at the start of your demo — it visibly proves there's no pre-baked dataset, which plays well with judges.

## Files

- `index.html` — page structure and styling
- `app.js` — camera pipeline, landmark normalization, KNN training/inference, speech I/O

## Known limitations (be upfront about these to judges)

- The KNN classifier is a static-pose recognizer — it classifies a held handshape, not a moving gesture. Real ISL includes motion and non-manual markers (facial expression, mouth patterns) that this prototype doesn't capture.
- Recognition quality depends entirely on how many/varied samples you capture per sign during setup — more samples and consistent lighting significantly improve accuracy.
- `SpeechRecognition` is a Chrome/Edge feature (WebKit Speech API) — it isn't supported in Firefox. Demo in Chrome.
- The "sign cue" side is currently a text label, not an actual ISL video/image — swap in real sign media for a production version (see below).

## Next steps if you keep building

- **Real sign cues**: replace the text-label cue cards with short video loops or illustrated hand-pose diagrams for each vocabulary word (a folder of `.mp4`/`.gif` per word, referenced by a lookup table, is enough for a stronger demo).
- **Two-hand and motion gestures**: MediaPipe Hands supports `maxNumHands: 2` — track sequences of frames (not just a single pose) and classify short motion trajectories for signs that require movement.
- **Offline support**: MediaPipe Hands and TF.js both run fully client-side already — for true offline use, self-host the CDN scripts (`hands.js`, `camera_utils.js`, `tf.min.js`, `knn-classifier.min.js`) instead of loading from jsdelivr, and cache them via a service worker.
- **Persisting trained gestures**: currently the KNN classifier resets on page reload. Serialize `knn.getClassifierDataset()` to `localStorage` or a backend so trained vocabularies persist across sessions.
